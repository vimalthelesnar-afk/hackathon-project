import express, { Request, Response, NextFunction } from 'express';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import crypto from 'crypto';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = parseInt(process.env.PORT || '3000', 10);

// Basic middleware
app.use(express.json());

// In-memory or file-backed storage
const DATA_DIR = path.join(__dirname, 'data');
const STORE_FILE = path.join(DATA_DIR, 'mint_store.json');

// Ensure data directory exists
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

interface DataStore {
  config: {
    eventName: string;
    tagline: string;
    eventDate: string;
    registrationOpen: boolean;
    submissionsOpen: boolean;
    totalPrizePool: string;
    demoModeActive: boolean;
  };
  registrations: any[];
  submissions: any[];
  leaderboard: any[];
  announcements: any[];
  adminTokens: Record<string, number>; // token -> expiry timestamp
}

// Default initial data
const DEFAULT_STORE: DataStore = {
  config: {
    eventName: 'MINT',
    tagline: 'Imagine. Innovate. Inspire.',
    eventDate: new Date(Date.now() + 28 * 24 * 60 * 60 * 1000).toISOString(),
    registrationOpen: true,
    submissionsOpen: true,
    totalPrizePool: '₹5,00,000 INR + Grants',
    demoModeActive: true,
  },
  registrations: [
    {
      id: 'MINT-2026-1042',
      teamName: 'NeuralVortex',
      leaderName: 'Arjun Swaminathan',
      leaderEmail: 'arjun.swaminathan@example.edu',
      contactNumber: '+91 98765 43210',
      institution: 'Indian Institute of Technology, Madras',
      state: 'Tamil Nadu',
      city: 'Chennai',
      memberCount: 4,
      members: [
        { name: 'Kavya Raman', email: 'kavya.r@example.edu', role: 'ML Researcher' },
        { name: 'Rohan Deshmukh', email: 'rohan.d@example.edu', role: 'Full Stack Dev' },
        { name: 'Sneha Patel', email: 'sneha.p@example.edu', role: 'Security Analyst' }
      ],
      category: 'Cybersecurity & Digital Safety',
      projectTitle: 'Deepfake Sentinel: Live Voice & Face Biometric Interceptor',
      projectDescription: 'Sub-250ms edge-compatible detector intercepting synthetic audio and video during live financial KYC with multi-modal facial blood-flow pulse extraction.',
      agreedToRules: true,
      status: 'Shortlisted',
      createdAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
    },
    {
      id: 'MINT-2026-2180',
      teamName: 'BioSync Labs',
      leaderName: 'Priya Nambiar',
      leaderEmail: 'priya.nambiar@example.edu',
      contactNumber: '+91 91234 56789',
      institution: 'Birla Institute of Technology and Science, Pilani',
      state: 'Rajasthan',
      city: 'Pilani',
      memberCount: 3,
      members: [
        { name: 'Vikram Joshi', email: 'vikram.j@example.edu', role: 'Embedded Systems' },
        { name: 'Ananya Sen', email: 'ananya.s@example.edu', role: 'Bioinformatics' }
      ],
      category: 'Healthcare Technology',
      projectTitle: 'PulseMesh: Quantized Edge Diagnostic Assistant for ASHA',
      projectDescription: 'Handheld quantized speech-to-text and reasoning engine running 100% offline on low-cost smartphones to assist rural health workers with preliminary clinical triage.',
      agreedToRules: true,
      status: 'Shortlisted',
      createdAt: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000).toISOString(),
    }
  ],
  submissions: [
    {
      id: 'SUB-2026-901',
      registrationId: 'MINT-2026-1042',
      teamName: 'NeuralVortex',
      projectTitle: 'Deepfake Sentinel: Live Voice & Face Biometric Interceptor',
      selectedCategory: 'Cybersecurity & Digital Safety',
      projectDescription: 'Real-time deepfake audio and video interception harness utilizing lightweight WebAssembly neural models and photoplethysmography anomaly analysis.',
      techStack: ['Python', 'WebRTC', 'WebAssembly', 'PyTorch', 'TypeScript'],
      repositoryUrl: 'https://github.com/mint-hackathon/neuralvortex-sentinel',
      demoVideoUrl: 'https://youtube.com/watch?v=sample-demo-sentinel',
      presentationUrl: 'https://speakerdeck.com/mint/deepfake-sentinel-2026',
      submittedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
      verified: true,
    }
  ],
  leaderboard: [
    {
      id: 'LB-01',
      rank: 1,
      teamName: 'NeuralVortex',
      projectTitle: 'Deepfake Sentinel: Live Voice & Face Biometric Interceptor',
      institution: 'Indian Institute of Technology, Madras',
      category: 'Cybersecurity & Digital Safety',
      preliminaryScore: 96.5,
      semiFinalScore: 98.0,
      finalScore: 97.2,
      totalScore: 97.2,
      status: 'Champion',
      isSampleData: true,
    },
    {
      id: 'LB-02',
      rank: 2,
      teamName: 'BioSync Labs',
      projectTitle: 'PulseMesh: Quantized Edge Diagnostic Assistant for ASHA',
      institution: 'Birla Institute of Technology and Science, Pilani',
      category: 'Healthcare Technology',
      preliminaryScore: 94.0,
      semiFinalScore: 96.5,
      finalScore: 96.0,
      totalScore: 95.5,
      status: 'Runner Up',
      isSampleData: true,
    },
    {
      id: 'LB-03',
      rank: 3,
      teamName: 'AetherVolt',
      projectTitle: 'SolarP2P: Decentralized Neighborhood Grid Balancing',
      institution: 'National Institute of Technology, Trichy',
      category: 'Green Technology & Sustainability',
      preliminaryScore: 92.0,
      semiFinalScore: 94.0,
      finalScore: 93.8,
      totalScore: 93.3,
      status: 'Grand Finalist',
      isSampleData: true,
    },
    {
      id: 'LB-04',
      rank: 4,
      teamName: 'ZeroLedger',
      projectTitle: 'ZkSolvent: Zero-Knowledge MSME Credit Underwriting',
      institution: 'Delhi Technological University',
      category: 'FinTech & Digital Innovation',
      preliminaryScore: 91.5,
      semiFinalScore: 92.5,
      finalScore: 93.0,
      totalScore: 92.3,
      status: 'Grand Finalist',
      isSampleData: true,
    },
    {
      id: 'LB-05',
      rank: 5,
      teamName: 'TactileLogic',
      projectTitle: 'AudioGeo: Binaural Spatial Geometry for Blind Scholars',
      institution: 'College of Engineering, Guindy',
      category: 'Education Technology',
      preliminaryScore: 89.0,
      semiFinalScore: 91.0,
      finalScore: 92.0,
      totalScore: 90.7,
      status: 'Shortlisted',
      isSampleData: true,
    },
    {
      id: 'LB-06',
      rank: 6,
      teamName: 'KineticsAI',
      projectTitle: 'VibroEdge: Predictive Bearing Cavitation Predictor',
      institution: 'Vellore Institute of Technology',
      category: 'Smart Automation',
      preliminaryScore: 88.0,
      semiFinalScore: 90.0,
      finalScore: 89.5,
      totalScore: 89.2,
      status: 'Shortlisted',
      isSampleData: true,
    },
    {
      id: 'LB-07',
      rank: 7,
      teamName: 'ReliefMesh',
      projectTitle: 'AdHocResQ: Browser-to-Browser Disaster Mesh',
      institution: 'RV College of Engineering, Bengaluru',
      category: 'Open Innovation',
      preliminaryScore: 87.5,
      semiFinalScore: 88.0,
      finalScore: 89.0,
      totalScore: 88.2,
      status: 'In Review',
      isSampleData: true,
    },
    {
      id: 'LB-08',
      rank: 8,
      teamName: 'VisionCare',
      projectTitle: 'GuardianPose: Skeletal Fall Detection with Zero Video Storage',
      institution: 'IIIT Hyderabad',
      category: 'Healthcare Technology',
      preliminaryScore: 86.0,
      semiFinalScore: 87.5,
      finalScore: 88.0,
      totalScore: 87.2,
      status: 'In Review',
      isSampleData: true,
    }
  ],
  announcements: [
    {
      id: 'ANN-01',
      title: 'Problem Statements & Evaluation Matrix Officially Published',
      content: 'All 8 challenge track briefs, dataset repositories, and grading rubrics are now available for registered teams. Please review the deliverables checklist carefully.',
      category: 'General',
      publishedAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
      priority: 'normal',
      author: 'MINT Organizing Secretariat',
    },
    {
      id: 'ANN-02',
      title: 'Team Registration Phase Enters Final 10-Day Window',
      content: 'Colleges and universities have registered over 450 teams so far. Ensure all team member profiles and institutional verification letters are finalized before November 10th.',
      category: 'Deadline',
      publishedAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
      priority: 'high',
      author: 'Admissions & Scrutiny Board',
    },
    {
      id: 'ANN-03',
      title: 'Upcoming National Masterclass: Scaling Edge AI & WebRTC Systems',
      content: 'Join leading cloud architects and AI researchers on October 29 at 05:00 PM IST for a live architectural walkthrough on low-latency inference pipelines.',
      category: 'Workshop',
      publishedAt: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000).toISOString(),
      priority: 'normal',
      author: 'MINT Technical Committee',
    }
  ],
  adminTokens: {}
};

function readStore(): DataStore {
  try {
    if (fs.existsSync(STORE_FILE)) {
      const content = fs.readFileSync(STORE_FILE, 'utf-8');
      return JSON.parse(content);
    }
  } catch (err) {
    console.error('Failed reading store file, using fallback in-memory store:', err);
  }
  return DEFAULT_STORE;
}

function writeStore(store: DataStore): void {
  try {
    fs.writeFileSync(STORE_FILE, JSON.stringify(store, null, 2), 'utf-8');
  } catch (err) {
    console.error('Failed writing store file:', err);
  }
}

// Initialize store if missing
if (!fs.existsSync(STORE_FILE)) {
  writeStore(DEFAULT_STORE);
}

// Admin Authentication Middleware
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'mint2026admin';

function requireAdminAuth(req: Request, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    res.status(401).json({ error: 'Unauthorized: Missing or malformed authorization token.' });
    return;
  }

  const token = authHeader.split(' ')[1];
  const store = readStore();
  const expiry = store.adminTokens[token];

  if (!expiry || Date.now() > expiry) {
    res.status(403).json({ error: 'Forbidden: Invalid or expired admin session token.' });
    return;
  }

  next();
}

// ======================== API ROUTES ========================

// Health check
app.get('/api/health', (req: Request, res: Response) => {
  res.json({
    status: 'ok',
    service: 'MINT Hackathon Core Backend',
    timestamp: new Date().toISOString(),
    demoMode: true,
  });
});

// Hackathon Config
app.get('/api/config', (req: Request, res: Response) => {
  const store = readStore();
  res.json(store.config);
});

app.put('/api/config', requireAdminAuth, (req: Request, res: Response) => {
  const store = readStore();
  const { eventDate, registrationOpen, submissionsOpen, totalPrizePool } = req.body;

  if (eventDate) store.config.eventDate = eventDate;
  if (typeof registrationOpen === 'boolean') store.config.registrationOpen = registrationOpen;
  if (typeof submissionsOpen === 'boolean') store.config.submissionsOpen = submissionsOpen;
  if (totalPrizePool) store.config.totalPrizePool = totalPrizePool;

  writeStore(store);
  res.json({ success: true, config: store.config });
});

// Admin Login
app.post('/api/admin/login', (req: Request, res: Response) => {
  const { password } = req.body;
  if (!password || typeof password !== 'string') {
    res.status(400).json({ error: 'Password is required' });
    return;
  }

  // Constant-time check where possible or secure string equality
  if (password.trim() === ADMIN_PASSWORD) {
    const token = 'mint_adm_' + crypto.randomBytes(24).toString('hex');
    const store = readStore();
    const expiry = Date.now() + 24 * 60 * 60 * 1000; // 24 hours
    store.adminTokens[token] = expiry;
    writeStore(store);

    res.json({
      success: true,
      token,
      expiresAt: new Date(expiry).toISOString(),
      message: 'Admin authorization successful',
    });
  } else {
    res.status(401).json({ error: 'Invalid administrator credentials. Access denied.' });
  }
});

// Team Registration
app.post('/api/registrations', (req: Request, res: Response) => {
  const {
    teamName,
    leaderName,
    leaderEmail,
    contactNumber,
    institution,
    state,
    city,
    memberCount,
    members,
    category,
    projectTitle,
    projectDescription,
    agreedToRules,
  } = req.body;

  // Validation
  if (!teamName || typeof teamName !== 'string' || teamName.trim().length < 3) {
    res.status(400).json({ error: 'Valid team name (minimum 3 characters) is required.' });
    return;
  }
  if (!leaderName || typeof leaderName !== 'string' || leaderName.trim().length < 2) {
    res.status(400).json({ error: 'Team leader full name is required.' });
    return;
  }
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!leaderEmail || !emailRegex.test(leaderEmail)) {
    res.status(400).json({ error: 'Valid team leader email address is required.' });
    return;
  }
  const phoneClean = (contactNumber || '').toString().replace(/[\s-]/g, '');
  if (!phoneClean || phoneClean.length < 8) {
    res.status(400).json({ error: 'Valid contact number is required.' });
    return;
  }
  if (!institution || institution.trim().length < 2) {
    res.status(400).json({ error: 'College or institution name is required.' });
    return;
  }
  if (!state || !city) {
    res.status(400).json({ error: 'State and city are required.' });
    return;
  }
  const count = parseInt(memberCount, 10);
  if (isNaN(count) || count < 2 || count > 4) {
    res.status(400).json({ error: 'Team size must be between 2 and 4 members.' });
    return;
  }
  if (!category) {
    res.status(400).json({ error: 'Selected challenge category is required.' });
    return;
  }
  if (!projectTitle || projectTitle.trim().length < 3) {
    res.status(400).json({ error: 'Project title is required.' });
    return;
  }
  if (!projectDescription || projectDescription.trim().length < 20) {
    res.status(400).json({ error: 'Project description must be at least 20 characters.' });
    return;
  }
  if (!agreedToRules) {
    res.status(400).json({ error: 'You must agree to the competition rules and guidelines.' });
    return;
  }

  const store = readStore();

  // Prevent duplicate team name or leader email
  const existingTeam = store.registrations.find(
    (r) =>
      r.teamName.toLowerCase() === teamName.trim().toLowerCase() ||
      r.leaderEmail.toLowerCase() === leaderEmail.trim().toLowerCase()
  );
  if (existingTeam) {
    res.status(409).json({
      error: `A registration with team name "${teamName}" or email "${leaderEmail}" already exists.`,
    });
    return;
  }

  // Generate unique Registration ID
  const randomSuffix = Math.floor(1000 + Math.random() * 9000);
  const registrationId = `MINT-2026-${randomSuffix}`;

  const newRegistration = {
    id: registrationId,
    teamName: teamName.trim(),
    leaderName: leaderName.trim(),
    leaderEmail: leaderEmail.trim().toLowerCase(),
    contactNumber: contactNumber.trim(),
    institution: institution.trim(),
    state: state.trim(),
    city: city.trim(),
    memberCount: count,
    members: Array.isArray(members) ? members : [],
    category,
    projectTitle: projectTitle.trim(),
    projectDescription: projectDescription.trim(),
    agreedToRules: true,
    status: 'Registered',
    createdAt: new Date().toISOString(),
  };

  store.registrations.unshift(newRegistration);
  writeStore(store);

  res.status(201).json({
    success: true,
    message: 'Team successfully registered for MINT 2026.',
    registrationId,
    registration: newRegistration,
  });
});

// Check Registration by ID or Email (Used for Submissions)
app.get('/api/registrations/verify/:query', (req: Request, res: Response) => {
  const query = req.params.query.trim().toLowerCase();
  const store = readStore();
  const match = store.registrations.find(
    (r) => r.id.toLowerCase() === query || r.leaderEmail.toLowerCase() === query
  );

  if (!match) {
    res.status(404).json({ error: 'Registration ID or Leader Email not found in official registry.' });
    return;
  }

  // Return public verification details (excluding private contact number)
  res.json({
    id: match.id,
    teamName: match.teamName,
    leaderName: match.leaderName,
    institution: match.institution,
    category: match.category,
    projectTitle: match.projectTitle,
    status: match.status,
  });
});

// Admin: Get all registrations
app.get('/api/registrations', requireAdminAuth, (req: Request, res: Response) => {
  const store = readStore();
  res.json(store.registrations);
});

// Admin: Update registration status
app.patch('/api/registrations/:id/status', requireAdminAuth, (req: Request, res: Response) => {
  const { id } = req.params;
  const { status } = req.body;
  const store = readStore();
  const team = store.registrations.find((r) => r.id === id);

  if (!team) {
    res.status(404).json({ error: 'Team not found' });
    return;
  }

  team.status = status;
  writeStore(store);
  res.json({ success: true, team });
});

// Project Submissions
app.post('/api/submissions', (req: Request, res: Response) => {
  const {
    registrationId,
    projectTitle,
    selectedCategory,
    projectDescription,
    techStack,
    repositoryUrl,
    demoVideoUrl,
    presentationUrl,
  } = req.body;

  if (!registrationId) {
    res.status(400).json({ error: 'Valid Team Registration ID is required to submit a project.' });
    return;
  }

  const store = readStore();
  const reg = store.registrations.find(
    (r) => r.id.toLowerCase() === registrationId.trim().toLowerCase()
  );

  if (!reg) {
    res.status(400).json({
      error: `Registration ID "${registrationId}" is not recognized. Please register your team first.`,
    });
    return;
  }

  if (!projectTitle || projectTitle.trim().length < 3) {
    res.status(400).json({ error: 'Project title is required.' });
    return;
  }
  if (!projectDescription || projectDescription.trim().length < 30) {
    res.status(400).json({ error: 'Project description must be at least 30 characters.' });
    return;
  }

  const urlRegex = /^https?:\/\/.+/i;
  if (!repositoryUrl || !urlRegex.test(repositoryUrl)) {
    res.status(400).json({ error: 'A valid code repository URL (https://...) is required.' });
    return;
  }
  if (!demoVideoUrl || !urlRegex.test(demoVideoUrl)) {
    res.status(400).json({ error: 'A valid video demonstration URL (https://...) is required.' });
    return;
  }

  const submissionId = `SUB-2026-${Math.floor(100 + Math.random() * 900)}`;

  const newSubmission = {
    id: submissionId,
    registrationId: reg.id,
    teamName: reg.teamName,
    projectTitle: projectTitle.trim(),
    selectedCategory: selectedCategory || reg.category,
    projectDescription: projectDescription.trim(),
    techStack: Array.isArray(techStack) ? techStack : [],
    repositoryUrl: repositoryUrl.trim(),
    demoVideoUrl: demoVideoUrl.trim(),
    presentationUrl: presentationUrl ? presentationUrl.trim() : '',
    submittedAt: new Date().toISOString(),
    verified: true,
  };

  // Replace existing submission for this registration if any, or push
  const existingIdx = store.submissions.findIndex((s) => s.registrationId === reg.id);
  if (existingIdx >= 0) {
    store.submissions[existingIdx] = newSubmission;
  } else {
    store.submissions.unshift(newSubmission);
  }

  // Update team status to Shortlisted or Submitted
  reg.status = 'Shortlisted';

  writeStore(store);

  res.status(201).json({
    success: true,
    message: 'Project deliverables submitted successfully to MINT Evaluation Server.',
    submissionId,
    submission: newSubmission,
  });
});

// Admin: Get all submissions
app.get('/api/submissions', requireAdminAuth, (req: Request, res: Response) => {
  const store = readStore();
  res.json(store.submissions);
});

// Leaderboard Routes
app.get('/api/leaderboard', (req: Request, res: Response) => {
  const store = readStore();
  // Return sorted by totalScore descending
  const sorted = [...store.leaderboard].sort((a, b) => b.totalScore - a.totalScore);
  // Re-assign ranks
  const withRanks = sorted.map((entry, idx) => ({ ...entry, rank: idx + 1 }));
  res.json(withRanks);
});

app.put('/api/leaderboard/:id', requireAdminAuth, (req: Request, res: Response) => {
  const { id } = req.params;
  const store = readStore();
  const entry = store.leaderboard.find((e) => e.id === id);

  if (!entry) {
    res.status(404).json({ error: 'Leaderboard entry not found' });
    return;
  }

  const { preliminaryScore, semiFinalScore, finalScore, status, projectTitle, teamName } = req.body;

  if (typeof preliminaryScore === 'number') entry.preliminaryScore = preliminaryScore;
  if (typeof semiFinalScore === 'number') entry.semiFinalScore = semiFinalScore;
  if (typeof finalScore === 'number') entry.finalScore = finalScore;
  if (status) entry.status = status;
  if (projectTitle) entry.projectTitle = projectTitle;
  if (teamName) entry.teamName = teamName;

  // Recalculate total score
  entry.totalScore = parseFloat(
    ((entry.preliminaryScore * 0.3) + (entry.semiFinalScore * 0.3) + (entry.finalScore * 0.4)).toFixed(1)
  );

  writeStore(store);
  res.json({ success: true, entry });
});

// Announcements Routes
app.get('/api/announcements', (req: Request, res: Response) => {
  const store = readStore();
  res.json(store.announcements);
});

app.post('/api/announcements', requireAdminAuth, (req: Request, res: Response) => {
  const { title, content, category, priority } = req.body;

  if (!title || !content) {
    res.status(400).json({ error: 'Title and content are required' });
    return;
  }

  const store = readStore();
  const newAnn = {
    id: `ANN-${Date.now().toString().slice(-4)}`,
    title: title.trim(),
    content: content.trim(),
    category: category || 'General',
    publishedAt: new Date().toISOString(),
    priority: priority || 'normal',
    author: 'MINT Organizing Board',
  };

  store.announcements.unshift(newAnn);
  writeStore(store);
  res.status(201).json({ success: true, announcement: newAnn });
});

app.delete('/api/announcements/:id', requireAdminAuth, (req: Request, res: Response) => {
  const { id } = req.params;
  const store = readStore();
  store.announcements = store.announcements.filter((a) => a.id !== id);
  writeStore(store);
  res.json({ success: true, message: 'Announcement deleted' });
});

// Contact Route
app.post('/api/contact', (req: Request, res: Response) => {
  const { name, email, subject, message } = req.body;

  if (!name || !email || !message) {
    res.status(400).json({ error: 'Name, email, and message are required.' });
    return;
  }

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    res.status(400).json({ error: 'Please enter a valid email address.' });
    return;
  }

  // Simulated receiving
  res.json({
    success: true,
    message: 'Your inquiry has been logged with the MINT Organizing Secretariat. A response will be dispatched within 24 hours.',
    ticketId: `TICK-${Math.floor(1000 + Math.random() * 9000)}`,
  });
});

// Mount Vite or serve static files
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'custom',
    });

    app.use(vite.middlewares);

    app.use('*', async (req: Request, res: Response, next: NextFunction) => {
      const url = req.originalUrl;
      try {
        const templatePath = path.resolve(__dirname, 'index.html');
        let template = fs.readFileSync(templatePath, 'utf-8');
        template = await vite.transformIndexHtml(url, template);
        res.status(200).set({ 'Content-Type': 'text/html' }).end(template);
      } catch (e: any) {
        vite.ssrFixStacktrace(e);
        next(e);
      }
    });
  } else {
    // Production: serve built static files
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[MINT Server] Running on http://0.0.0.0:${PORT}`);
  });
}

startServer();

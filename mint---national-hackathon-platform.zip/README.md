# MINT — National Innovation Hackathon Platform

> **"Imagine. Innovate. Inspire."**  
> Official web platform for the national-level technology hackathon competition.

---

## 🚀 Overview

**MINT** is a futuristic, modern, and production-grade hackathon competition platform engineered for national-level innovation sprints. Built with **React 19**, **TypeScript**, **Tailwind CSS v4**, and an **Express full-stack backend**, MINT empowers collegiate innovators, researchers, and developers to compete across 8 mission-critical challenge tracks.

### Key Capabilities
- **Futuristic Brand Identity**: Dark obsidian & navy aesthetic with mint-green luminous accents, glassmorphic surfaces, and responsive layouts.
- **Hackathon Countdown Timer**: Dynamic real-time countdown to the Grand Finale Sprint with tabular numerals and configurable dates.
- **8 National Challenge Tracks**: Cybersecurity & Digital Safety, AI/ML, Smart Automation, Healthcare Tech, Green Tech, FinTech, EdTech, and Open Innovation.
- **Interactive Problem Statement Modals**: Deep-dive specifications, expected deliverables, suggested technology stacks, and evaluation pointers.
- **End-to-End Team Registration**: Multi-member registration form (2–4 members) with validation, duplicate detection, and unique Registration ID generation (`MINT-2026-XXXX`).
- **Live Leaderboard**: Real-time evaluation table with search, category filtering, score breakdowns (preliminary, semi, final), and clear demonstration disclaimers.
- **Deliverable Submission Portal**: Teams verify their Registration ID and submit GitHub repository links, video walkthroughs, and architecture whitepapers.
- **Event Roadmap**: 7-phase timeline with one-click **Add to Calendar (.ics)** export.
- **Protected Admin Console**: Secure administrator portal for managing registrations, reviewing project submissions, updating scores, posting circulars, and modifying event parameters.
- **Announcements Bulletin**: Categorized circulars (Urgent, Deadlines, Workshops, Results) with priority badges.
- **Searchable FAQ & Support Desk**: Interactive accordion and validated inquiry form.

---

## 📁 Project File Structure

```
├── .env.example              # Environment variables template
├── .gitignore                # Git ignore configuration
├── index.html                # HTML entry point with metadata & Google Fonts
├── metadata.json             # Applet capabilities & metadata
├── package.json              # Dependencies and lifecycle scripts
├── server.ts                 # Full-stack Express server + Vite dev middleware
├── tsconfig.json             # TypeScript compiler configuration
├── vite.config.ts            # Vite configuration with Tailwind CSS v4
├── data/
│   └── mint_store.json       # Persistent data store (registrations, scores, etc.)
└── src/
    ├── main.tsx              # React DOM entry point
    ├── App.tsx               # Root application layout and orchestration
    ├── index.css             # Tailwind v4 import & custom glow/typography tokens
    ├── types/
    │   └── index.ts          # Domain interfaces & TypeScript types
    ├── data/
    │   └── mockData.ts       # Challenge statements, initial timeline, FAQs, prizes
    ├── services/
    │   └── api.ts            # Client API client with offline demo resilience
    ├── assets/
    │   └── images/           # Generated high-resolution hackathon imagery
    └── components/
        ├── Navbar.tsx        # Top navigation adhering to 3-zone contract
        ├── Hero.tsx          # Hero banner, countdown timer & demo statistics
        ├── About.tsx         # Mission, rules, evaluation rubric & prize tiers
        ├── Challenges.tsx    # 8 Tracks & detailed problem statement drawer
        ├── RegistrationSection.tsx # Team registration form & ID generator
        ├── SubmissionSection.tsx   # Project deliverable submission portal
        ├── Leaderboard.tsx   # Standings, category filters & scoring breakdown
        ├── Schedule.tsx      # 7-phase event timeline & .ics calendar generator
        ├── Announcements.tsx # Bulletin circulars & deadline alerts
        ├── FaqContact.tsx    # Searchable FAQ & operational contact form
        ├── AdminDashboard.tsx# Protected administrator dashboard
        └── Footer.tsx        # Footer with links, copyright & contact desk
```

---

## 🛠️ Quick Start & Local Development

### 1. Prerequisites
- **Node.js**: `v18.0.0` or higher
- **npm**: `v9.0.0` or higher

### 2. Installation
Clone the repository and install all dependencies:
```bash
git clone https://github.com/your-username/mint-hackathon.git
cd mint-hackathon
npm install
```

### 3. Configure Environment Variables
Copy `.env.example` to `.env`:
```bash
cp .env.example .env
```
Key configuration values:
- `PORT=3000`: Port where the server runs.
- `ADMIN_PASSWORD="mint2026admin"`: Secret key used to access the `/api/admin/*` console. Change this to a secure random password in production!

### 4. Start Development Server
```bash
npm run dev
```
Open [http://localhost:3000](http://localhost:3000) in your browser. The Express server serves both the REST API at `/api/*` and Vite frontend hot-reloading.

### 5. Production Build
```bash
npm run build
npm start
```

---

## 🔐 Administrator Portal Access

1. Click **Admin Console** in the top navigation bar or the footer.
2. Enter the administrator secret password:
   - **Default Local/Demo Password**: `mint2026admin`
   - *In production, configure this via the `ADMIN_PASSWORD` environment variable.*
3. Inside the Admin Console, you can:
   - **Teams Registry**: Filter, search, and update registration statuses (`Registered`, `Shortlisted`, `Finalist`, `Disqualified`).
   - **Project Submissions**: Inspect GitHub repository URLs, demo video links, and review technology stacks.
   - **Leaderboard Scoring**: Live calibrate preliminary, semifinal, and final points for any team.
   - **Announcements**: Publish official circulars with custom priorities.
   - **Event Parameters**: Adjust the countdown target date or toggle registration windows.

---

## ☁️ Deployment Guide

### Deploying to GitHub

1. Initialize a new Git repository:
   ```bash
   git init
   git add .
   git commit -m "feat: initial commit of MINT hackathon platform"
   ```
2. Create a new repository on [GitHub](https://github.com/new).
3. Link your local repo and push:
   ```bash
   git remote add origin https://github.com/<your-username>/mint-hackathon.git
   git branch -M main
   git push -u origin main
   ```

### Deploying to Vercel

MINT is built to deploy effortlessly to Vercel using either standard static hosting or full-stack Node.js serverless functions:

#### Option A: Static Web Application (Free Tier)
1. Log in to [Vercel](https://vercel.com) and click **"Add New Project"**.
2. Select your imported `mint-hackathon` GitHub repository.
3. Vercel will automatically detect **Vite**:
   - **Framework Preset**: `Vite`
   - **Build Command**: `npm run build`
   - **Output Directory**: `dist`
   - **Install Command**: `npm install`
4. Under **Environment Variables**, add:
   - `ADMIN_PASSWORD`: Your custom secret key for the admin portal.
5. Click **Deploy**.
6. When running as a static export, `src/services/api.ts` automatically switches to client-side local resilience fallback mode with local storage persistence.

#### Option B: Full-Stack Cloud Run / Render / Railway
If you wish to run the persistent Express backend continuously:
1. Connect repository to [Render](https://render.com) or [Railway](https://railway.app).
2. Set **Build Command**: `npm install && npm run build`
3. Set **Start Command**: `npm start`
4. Set environment variable `ADMIN_PASSWORD`.

---

## 🗄️ Database & Production Backend Integration

The current setup utilizes a persistent file-backed JSON store in `data/mint_store.json` that retains all registrations, submissions, and leaderboard scores across restarts.

To connect a production relational database (e.g. **PostgreSQL**, **Cloud SQL**, **Supabase**, or **Neon**):
1. Install Drizzle ORM or Prisma:
   ```bash
   npm install pg drizzle-orm
   ```
2. Replace the file read/write methods in `server.ts` with standard SQL queries against your `DATABASE_URL`.
3. Set `DATABASE_URL="postgresql://user:password@host:5432/mint_hackathon"` in your hosting environment variables.

---

## ❓ Troubleshooting

| Issue | Cause | Resolution |
| :--- | :--- | :--- |
| `Port 3000 already in use` | Another process is holding port 3000 | Set `PORT=3001` in `.env` or terminate the conflicting process. |
| `Invalid administrator credentials` | Password does not match `ADMIN_PASSWORD` | Use `mint2026admin` (default demo password) or verify your `.env` value. |
| `Registration ID not found` during submission | The team has not registered yet | Register the team first on the Registration page to obtain an official `MINT-2026-XXXX` ID. |
| `Vite build fails` | Stale cache or missing dependencies | Run `npm run clean && npm install && npm run build`. |

---

## 📜 License & Intellectual Property

Participating teams retain **100% intellectual property rights** over their code, designs, and architectures.  
Platform code released under the **Apache-2.0 License**.
